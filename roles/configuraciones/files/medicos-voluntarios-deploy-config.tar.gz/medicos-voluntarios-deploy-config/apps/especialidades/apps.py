from django.apps import AppConfig


class EspecialidadesConfig(AppConfig):
    name = "especialidades"
