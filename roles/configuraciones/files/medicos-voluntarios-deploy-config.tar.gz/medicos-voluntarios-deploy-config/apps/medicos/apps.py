from django.apps import AppConfig


class MedicosConfig(AppConfig):
    name = "medicos"
