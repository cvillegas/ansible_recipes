from django.contrib import admin

from .models import Contacto, Persona

admin.site.register(Persona)
admin.site.register(Contacto)
