from django.apps import AppConfig


class PersonaConfig(AppConfig):
    name = "persona"
