from django.apps import AppConfig


class TermsConfig(AppConfig):
    name = "apps.terms"
    verbose_name = "Términos y condiciones"
    label = "terms"
