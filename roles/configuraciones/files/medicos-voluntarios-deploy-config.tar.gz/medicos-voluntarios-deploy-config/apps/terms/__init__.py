default_app_config = "apps.terms.apps.TermsConfig"
