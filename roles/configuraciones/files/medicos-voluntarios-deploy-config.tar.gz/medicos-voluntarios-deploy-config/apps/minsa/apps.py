from django.apps import AppConfig


class MinsaConfig(AppConfig):
    name = "apps.minsa"
